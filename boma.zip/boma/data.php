<?php
// Database details
$db_server   = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name     = 'boma';
$connection=mysql_connect($db_server,$db_username,$db_password)or die('Could not create a connection to the database : '.mysql_error());

mysql_select_db($db_name) or die('Could not select the database : '.mysql_error());
function showE(){
die("Error " . mysql_errno() . " : " . mysql_error( ));
}

include_once "../newdms/assets/lib/functions.php";
// Get job (and id)
$job = '';
$id  = '';
if (isset($_GET['job'])){
  $job = $_GET['job'];
  if ($job == 'get_members' ||
      $job == 'get_member'   ||
      $job == 'add_member'   ||
      $job == 'edit_member'  ||
      $job == 'delete_member'){
    if (isset($_GET['id'])){
      $id = $_GET['id'];
      if (!is_numeric($id)){
        $id = '';
      }
    }
  } else {
    $job = '';
  }
}

// Prepare array
$mysql_data = array();

// Valid job found
if ($job != ''){
  
  // Connect to database
  $db_connection = mysqli_connect($db_server, $db_username, $db_password, $db_name);
  if (mysqli_connect_errno()){
    $result  = 'error';
    $message = 'Failed to connect to database: ' . mysqli_connect_error();
    $job     = '';
  }
  
  // Execute job
  if ($job == 'get_members'){
    $i=1;
    // Get companies
    $query = "SELECT * FROM tbl_members where status=0 ORDER BY member_id";
    $query = mysqli_query($db_connection, $query);
    if (!$query){
      $result  = 'error';
      $message = 'query error';
    } else {
      $result  = 'success';
      $message = 'query success';
      while ($company = mysqli_fetch_array($query)){
        $functions  = '<div class="function_buttons"><ul>';
        $functions .= '<li class="function_edit"><a data-id="'   . $company['member_id'] . '" data-name="' . $company['member_name'] . '"><span>Edit</span></a></li>';
        $functions .= '<li class="function_delete"><a data-id="' . $company['member_id'] . '" data-name="' . $company['member_name'] . '"><span>Delete</span></a></li>';
        $functions .= '</ul></div>';
        $mysql_data[] = array(
		
          "No"          => $i,
		   "member_name" => "<a href='member.php?id=".$company['member_id']."'>".$company['member_name']."</a>",
		   "amount"  => $company['amount'],
			 "contact"  => $company['contact'],
			 "reg_date"    => $company['reg_date'],
			  "tenure"    => $company['tenure'],
			"reg_by"     => $company['reg_by'],
			"repayment_frequency"  =>  $company['repayment_frequency'],
          "amount"   => $company['amount'],
		   "legal_fees"    => $company['legal_fees'],
          "interest_rate"    => $company['interest_rate'],
          "status"       => $company['status'],
        "total"=>$company['amount']+$company['legal_fees'],
		 
          "functions"     => $functions
        );///end array
     $i++; }
    }
    
  } elseif ($job == 'get_member'){
    
    // Get company
    if ($id == ''){
      $result  = 'error';
      $message = 'id missing';
    } else {
      $query = "SELECT * FROM tbl_members WHERE member_id = '" . mysqli_real_escape_string($db_connection, $id) . "'";
      $query = mysqli_query($db_connection, $query);
      if (!$query){
        $result  = 'error';
        $message = 'query error';
      } else {
        $result  = 'success';
        $message = 'query success';
        while ($company = mysqli_fetch_array($query)){
          $mysql_data[] = array(
          
          "No"          => $i,
		   "member_name" => $company['member_name'],
		   "amount"  => $company['amount'],
			"interest_rate"    =>  $company['interest_rate'],
			"tenure"     =>  $company['tenure'],
			"repayment_frequency"  =>  $company['repayment_frequency'],
          "legal_fees"   => $company['legal_fees'],
		  "contact"  => $company['contact'],
        //  "phone"    => $company['phone'],
          "reg_by"       => $company['added_by'],
         "reg_date"    => $company['reg_date'],
        
          
          );
        }
      }
    }
  
  } elseif ($job == 'add_member'){
      // Add company
    $query = "INSERT INTO tbl_members SET ";
    if (isset($_GET['amount']))         { $query .= "amount = '" . mysqli_real_escape_string($db_connection, $_GET['amount'])         . "', "; }
    if (isset($_GET['member_name'])) { $query .= "member_name = '" . mysqli_real_escape_string($db_connection, $_GET['member_name']) . "', "; }
    if (isset($_GET['contact']))   { $query .= "contact   = '" . mysqli_real_escape_string($db_connection, $_GET['contact'])   . "', "; }
    if (isset($_GET['']))      { $query .= "      = '" . mysqli_real_escape_string($db_connection, $_GET[''])      . "', "; }
    if (isset($_GET['interest_rate']))  { $query .= "interest_rate  = '" . mysqli_real_escape_string($db_connection, $_GET['interest_rate'])  . "', "; }
    if (isset($_GET['tenure']))    { $query .= "tenure = '" . mysqli_real_escape_string($db_connection, $_GET['tenure'])    . "', "; }
    if (isset($_GET['repayment_frequency']))   { $query .= "repayment_frequency   = '" . mysqli_real_escape_string($db_connection, $_GET['repayment_frequency'])   . "', "; }
     if (isset($_GET['amount'])) { $query .= "legal_fees = '" . legal($_GET['amount'])."'";   }
    $query = mysqli_query($db_connection, $query);
    if (!$query){
      $result  = 'error';
      $message = mysqli_error($db_connection);
    } else {
      $result  = 'success';
      $message = 'query success';
    }
  
  } elseif ($job == 'edit_member'){
    
    // Edit company
    if ($id == ''){
      $result  = 'error';
      $message = 'id missing';
    } else {
      $query = "UPDATE tbl_members SET ";
      if (isset($_GET['amount']))         { $query .= "amount= '" . mysqli_real_escape_string($db_connection, $_GET['amount'])         . "', "; }
      if (isset($_GET['member_name'])) { $query .= "member_name = '" . mysqli_real_escape_string($db_connection, $_GET['member_name']) . "', "; }
      if (isset($_GET['contact']))   { $query .= "contact   = '" . mysqli_real_escape_string($db_connection, $_GET['contact'])   . "', "; }
      if (isset($_GET['']))      { $query .= "      = '" . mysqli_real_escape_string($db_connection, $_GET[''])      . "', "; }
      if (isset($_GET['interest_rate']))  { $query .= "interest_rate  = '" . mysqli_real_escape_string($db_connection, $_GET['interest_rate'])  . "', "; }
      if (isset($_GET['tenure']))    { $query .= "tenure    = '" . mysqli_real_escape_string($db_connection, $_GET['tenure'])    . "', "; }
      if (isset($_GET['repayment_frequency']))   { $query .= "repayment_frequency   = '" . mysqli_real_escape_string($db_connection, $_GET['repayment_frequency'])   . "', "; }
      if (isset($_GET['amount'])) { $query .= "legal_fees = '" . legal($_GET['amount'])."'";   }
      $query .= "WHERE company_id = '" . mysqli_real_escape_string($db_connection, $id) . "'";
      $query  = mysqli_query($db_connection, $query);
      if (!$query){
        $result  = 'error';
        $message = 'query error';
      } else {
        $result  = 'success';
        $message = 'query success';
      }
    }
    
  } elseif ($job == 'delete_member'){
  
    // Delete company
    if ($id == ''){
      $result  = 'error';
      $message = 'id missing';
    } else {
      $query = "DELETE FROM tbl_members WHERE member_id = '" . mysqli_real_escape_string($db_connection, $id) . "'";
      $query = mysqli_query($db_connection, $query);
      if (!$query){
        $result  = 'error';
        $message = 'query error';
      } else {
        $result  = 'success';
        $message = 'query success';
      }
    }
  
  }
  
  // Close database connection
  mysqli_close($db_connection);

}

// Prepare data
$data = array(
  "result"  => $result,
  "message" => $message,
  "data"    => $mysql_data
);

function legal($amount){
	if($amount<=10000){
		return 6.5*$amount/100;
		} 
		else if($amount<=250000){
		return 6*$amount/100;
		}
		else if($amount<=500000){
		return 5.5*$amount/100;
		}
		else if($amount<=1000000){
		return 5*$amount/100;
		}
				else {
		return 4*$amount/100;
		}
	}
// Convert PHP array to JSON array
$json_data = json_encode($data);
print $json_data;
?>