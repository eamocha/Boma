-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2016 at 11:41 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boma`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_installments`
--

CREATE TABLE `tbl_installments` (
  `installment_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `member` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_installments`
--

INSERT INTO `tbl_installments` (`installment_id`, `amount`, `member`, `date_added`) VALUES
(1, 3, 2, '2016-08-08 14:21:45'),
(2, 500, 4, '2016-08-08 14:22:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_members`
--

CREATE TABLE `tbl_members` (
  `member_id` int(11) NOT NULL,
  `member_name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reg_by` varchar(250) NOT NULL DEFAULT 'Eric Atinga',
  `repayment_frequency` varchar(30) DEFAULT NULL,
  `amount` varchar(30) DEFAULT NULL,
  `interest_rate` varchar(30) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `legal_fees` int(11) DEFAULT NULL,
  `tenure` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_members`
--

INSERT INTO `tbl_members` (`member_id`, `member_name`, `contact`, `reg_date`, `reg_by`, `repayment_frequency`, `amount`, `interest_rate`, `status`, `legal_fees`, `tenure`) VALUES
(1, 'Eric Atinga', '0723459876', '2016-08-08 08:11:18', '0', '43', NULL, '2', 0, 3, '2'),
(2, 'Eric Mocha', '0727755095', '2016-08-08 09:42:01', 'Eric Atinga', '4', NULL, '4', 0, 43, '1'),
(3, 'Eric Atinga', '0723459876', '2016-08-08 09:54:37', 'Eric Atinga', '14', NULL, '12', 0, 54, '12'),
(4, 'Eric Atinga ghwe', '0723459876', '2016-08-08 10:00:50', 'Eric Atinga', '12', '12000', '12', 0, 43, '12'),
(5, 'Mre ', '07425242', '2016-08-08 10:32:00', 'Eric Atinga', '12', '3222', '8', 0, 12, '12'),
(6, 'Boma 1', '07425242', '2016-08-08 10:35:35', 'Eric Atinga', '12', '12', '12', 0, 1, '12'),
(7, 'Mr. Otieno', '0754276527', '2016-08-08 11:13:15', 'Eric Atinga', '12', '700', '3', 0, 46, '36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_installments`
--
ALTER TABLE `tbl_installments`
  ADD PRIMARY KEY (`installment_id`);

--
-- Indexes for table `tbl_members`
--
ALTER TABLE `tbl_members`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_installments`
--
ALTER TABLE `tbl_installments`
  MODIFY `installment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_members`
--
ALTER TABLE `tbl_members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
