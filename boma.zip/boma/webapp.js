$(document).ready(function(){
  
  // On page load: datatable
  var table_members = $('#table_members').dataTable({
    "ajax": "data.php?job=get_members",
    "columns": [
	       
      { "data": "No" },
      { "data": "member_name",  },
      { "data": "amount" },
      { "data": "interest_rate" },
      { "data": "tenure" },
      { "data": "repayment_frequency" },
	  { "data": "legal_fees" },
	  { "data": "total" },
      { "data": "contact" },
      
	  { "data": "reg_by" },
	{ "data": "reg_date" },
	
      { "data": "functions",      "sClass": "functions" }
    ],
    "aoColumnDefs": [
      { "bSortable": false, "aTargets": [-1] }
    ],
    "lengthMenu": [[10, 25, 50, 100,200, -1], [10, 25, 50, 100,200, "All"]],
    "oLanguage": {
      "oPaginate": {
        "sFirst":       " ",
        "sPrevious":    " ",
        "sNext":        " ",
        "sLast":        " ",
      },
      "sLengthMenu":    "Records per page: _MENU_",
      "sInfo":          "Total of _TOTAL_ records (showing _START_ to _END_)",
      "sInfoFiltered":  "(filtered from _MAX_ total records)"
    }
  });
  
  // On page load: form validation
  jQuery.validator.setDefaults({
    success: 'valid',
    rules: {
      interest_rate: {
        required: true,
        min:      1,
        max:      100
      }
    },
    errorPlacement: function(error, element){
      error.insertBefore(element);
    },
    highlight: function(element){
      $(element).parent('.field_container').removeClass('valid').addClass('error');
    },
    unhighlight: function(element){
      $(element).parent('.field_container').addClass('valid').removeClass('error');
    }
  });
  var form_member = $('#form_member');
  form_member.validate();

  // Show message
  function show_message(message_text, message_type){
    $('#message').html('<p>' + message_text + '</p>').attr('class', message_type);
    $('#message_container').show();
    if (typeof timeout_message !== 'undefined'){
      window.clearTimeout(timeout_message);
    }
    timeout_message = setTimeout(function(){
      hide_message();
    }, 8000);
  }
  // Hide message
  function hide_message(){
    $('#message').html('').attr('class', '');
    $('#message_container').hide();
  }

  // Show loading message
  function show_loading_message(){
    $('#loading_container').show();
  }
  // Hide loading message
  function hide_loading_message(){
    $('#loading_container').hide();
  }

  // Show lightbox
  function show_lightbox(){
    $('.lightbox_bg').show();
    $('.lightbox_container').show();
  }
  // Hide lightbox
  function hide_lightbox(){
    $('.lightbox_bg').hide();
    $('.lightbox_container').hide();
  }
  // Lightbox background
  $(document).on('click', '.lightbox_bg', function(){
    hide_lightbox();
  });
  // Lightbox close button
  $(document).on('click', '.lightbox_close', function(){
    hide_lightbox();
  });
  // Escape keyboard key
  $(document).keyup(function(e){
    if (e.keyCode == 27){
      hide_lightbox();
    }
  });
  
  // Hide iPad keyboard
  function hide_ipad_keyboard(){
    document.activeElement.blur();
    $('input').blur();
  }

  // Add member button
  $(document).on('click', '#add_member', function(e){
    e.preventDefault();
    $('.lightbox_content h2').text('Add Member');
    $('#form_member button').text('Add Member');
    $('#form_member').attr('class', 'form add');
    $('#form_member').attr('data-id', '');
    $('#form_member .field_container label.error').hide();
    $('#form_member .field_container').removeClass('valid').removeClass('error');
    $('#form_member #amount').val('');
    $('#form_member #member_name').val('');
    $('#form_member #contact').val('');
    $('#form_member #amount').val('');
    $('#form_member #interest_rate').val('');
    $('#form_member #tenure').val('');
    $('#form_member #repayment_frequency').val('');
    $('#form_member #legal_fees').val('');
    show_lightbox();
  });

  // Add member submit form
  $(document).on('submit', '#form_member.add', function(e){
    e.preventDefault();
    // Validate form
    if (form_member.valid() == true){
      // Send member information to database
      hide_ipad_keyboard();
      hide_lightbox();
      show_loading_message();
      var form_data = $('#form_member').serialize();
      var request   = $.ajax({
        url:          'data.php?job=add_member',
        cache:        false,
        data:         form_data,
        dataType:     'json',
        contentType:  'application/json; charset=utf-8',
        type:         'get'
      });
      request.done(function(output){
        if (output.result == 'success'){
          // Reload datable
          table_members.api().ajax.reload(function(){
            hide_loading_message();
            var member_name = $('#member_name').val();
            show_message("Member '" + member_name + "' added successfully.", 'success');
          }, true);
        } else {
          hide_loading_message();
          show_message('Add request failed', 'error');
        }
      });
      request.fail(function(jqXHR, textStatus){
        hide_loading_message();
        show_message('Add request failed: ' + textStatus, 'error');
      });
    }
  });

  // Edit member button
  $(document).on('click', '.function_edit a', function(e){
    e.preventDefault();
    // Get member information from database
    show_loading_message();
    var id      = $(this).data('id');
    var request = $.ajax({
      url:          'data.php?job=get_member',
      cache:        false,
      data:         'id=' + id,
      dataType:     'json',
      contentType:  'application/json; charset=utf-8',
      type:         'get'
    });
    request.done(function(output){
      if (output.result == 'success'){
        $('.lightbox_content h2').text('Edit Member');
        $('#form_member button').text('Edit Member');
        $('#form_member').attr('class', 'form edit');
        $('#form_member').attr('data-id', id);
        $('#form_member .field_container label.error').hide();
        $('#form_member .field_container').removeClass('valid').removeClass('error');
		$('#form_member #amount').val(output.data[0].amount);
        $('#form_member #member_name').val(output.data[0].member_name);
        $('#form_member #contact').val(output.data[0].contact);
        $('#form_member #amount').val(output.data[0].amount);
        $('#form_member #interest_rate').val(output.data[0].interest_rate);
        $('#form_member #tenure').val(output.data[0].tenure);
        $('#form_member #repayment_frequency').val(output.data[0].repayment_frequency);
        $('#form_member #legal_fees').val(output.data[0].legal_fees);
        hide_loading_message();
        show_lightbox();
      } else {
        hide_loading_message();
        show_message('Information request failed', 'error');
      }
    });
    request.fail(function(jqXHR, textStatus){
      hide_loading_message();
      show_message('Information request failed: ' + textStatus, 'error');
    });
  });
  
  // Edit member submit form
  $(document).on('submit', '#form_member.edit', function(e){
    e.preventDefault();
    // Validate form
    if (form_member.valid() == true){
      // Send member information to database
      hide_ipad_keyboard();
      hide_lightbox();
      show_loading_message();
      var id        = $('#form_member').attr('data-id');
      var form_data = $('#form_member').serialize();
      var request   = $.ajax({
        url:          'data.php?job=edit_member&id=' + id,
        cache:        false,
        data:         form_data,
        dataType:     'json',
        contentType:  'application/json; charset=utf-8',
        type:         'get'
      });
      request.done(function(output){
        if (output.result == 'success'){
          // Reload datable
          table_members.api().ajax.reload(function(){
            hide_loading_message();
            var member_name = $('#member_name').val();
            show_message("Member '" + member_name + "' edited successfully.", 'success');
          }, true);
        } else {
          hide_loading_message();
          show_message('Edit request failed', 'error');
        }
      });
      request.fail(function(jqXHR, textStatus){
        hide_loading_message();
        show_message('Edit request failed: ' + textStatus, 'error');
      });
    }
  });
  
  // Delete member
  $(document).on('click', '.function_delete a', function(e){
    e.preventDefault();
    var member_name = $(this).data('name');
    if (confirm("Are you sure you want to delete '" + member_name + "'?")){
      show_loading_message();
      var id      = $(this).data('id');
      var request = $.ajax({
        url:          'data.php?job=delete_member&id=' + id,
        cache:        false,
        dataType:     'json',
        contentType:  'application/json; charset=utf-8',
        type:         'get'
      });
      request.done(function(output){
        if (output.result == 'success'){
          // Reload datable
          table_members.api().ajax.reload(function(){
            hide_loading_message();
            show_message("Member '" + member_name + "' deleted successfully.", 'success');
          }, true);
        } else {
          hide_loading_message();
          show_message('Delete request failed', 'error');
        }
      });
      request.fail(function(jqXHR, textStatus){
        hide_loading_message();
        show_message('Delete request failed: ' + textStatus, 'error');
      });
    }
  });

});