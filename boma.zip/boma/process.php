<?php 
$db_server   = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name     = 'boma';
$connection=mysql_connect($db_server,$db_username,$db_password)or die('Could not create a connection to the database : '.mysql_error());

mysql_select_db($db_name) or die('Could not select the database : '.mysql_error());
function showE(){
die("Error " . mysql_errno() . " : " . mysql_error( ));
}

include_once "../newdms/assets/lib/functions.php";

$amount=$_REQUEST['amount'];
$member=$_REQUEST['id'];
$insert = mysql_query("INSERT INTO tbl_installments( member, amount) VALUES($member, $amount)") or die(mysql_error());
header("location: index.html");
?>