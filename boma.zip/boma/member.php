<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <title>Loans Management System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=1000, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
   <?php
   $db_server   = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name     = 'boma';
$connection=mysql_connect($db_server,$db_username,$db_password)or die('Could not create a connection to the database : '.mysql_error());

mysql_select_db($db_name) or die('Could not select the database : '.mysql_error());
function showE(){
die("Error " . mysql_errno() . " : " . mysql_error( ));
}

include_once "../newdms/assets/lib/functions.php";?>
    
    <link rel="stylesheet" href="layout.css">
   

    <link rel="stylesheet" href="font-awesome.min.css">
    <link rel="stylesheet" href="layout.css">
    <script charset="utf-8" src="jquery.min.js"></script>
    <script charset="utf-8" src="jquery.dataTables.js"></script>
    <script charset="utf-8" src="jquery.validate.min.js"></script>
    <script charset="utf-8" src="webapp.js"></script>
  </head>
  <body>

  <div id="page_container">
<h1>Member: .....<?php echo $_REQUEST['id']?></h1>
<table class="datatable" >
       
        <tbody><form name="form1" method="post" action="process.php? id=<?php echo $_REQUEST['id']?>">
        <tr>        <td>Amount</td>
        <td>
          <label for="amount"></label>
          <input type="text" name="amount" id="amount">
        </td>
        <td>&nbsp;</td>
        </tr>
         <tr>        <td>By</td>
         <td><input type="text" name="by" id="by"></td>
         <td></td>
         </tr>
        </tbody>
   <button  class="button" type="submit">submit</button></form> </table>

<h1>Repayment details</h1>
<table class="datatable" >
       
         
        <tbody>
        <tr><td>Date</td>
          <td>Amount</td>
          <td>Ref No</td>
          <td>&nbsp;</td></tr>
          <?php $sql=mysql_query("SELECT * FROM tbl_installments");
		  while($row=mysql_fetch_array($sql)){
			  
			  
			 ?><tr
          <td><? echo $row['date_added'];?></td>
          <td><?php  echo  $row['amount'];?></td>
          <td></td>
          <td>&nbsp;</td>
          </tr><?php } ?>
        </tbody>
    </table>
      

    </div>

    

  </body>
</html>